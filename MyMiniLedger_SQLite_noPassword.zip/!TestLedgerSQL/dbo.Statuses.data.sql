SET IDENTITY_INSERT [dbo].[Statuses] ON
INSERT INTO [dbo].[Statuses] ([Id], [StatusName], [StatusNotes]) VALUES (4, N'Closed', N'Позиция закрыта')
INSERT INTO [dbo].[Statuses] ([Id], [StatusName], [StatusNotes]) VALUES (5, N'Open', N'Позиция открыта')
INSERT INTO [dbo].[Statuses] ([Id], [StatusName], [StatusNotes]) VALUES (6, N'Deleted', N'Позиция позиция удалена')
SET IDENTITY_INSERT [dbo].[Statuses] OFF
