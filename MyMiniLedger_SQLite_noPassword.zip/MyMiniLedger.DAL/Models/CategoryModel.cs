﻿using MyMiniLedger.DAL.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MyMiniLedger.DAL.Models
{
	public class CategoryModel
	{
        public int Id { get; set; }
        public string  Category { get; set; }
    }
   
}
